</div>
</div>


<!-- begin:: Footer -->
<div class="kt-footer  kt-footer--extended  kt-grid__item" id="kt_footer" style="background-image: url('newassets/media/bg/bg-2.jpg');">

    <div class="kt-footer__bottom">
        <div class="kt-container ">
            <div class="kt-footer__wrapper">
                <div class="kt-footer__logo">
                    <div class="kt-footer__copyright">
                        <?php echo date('Y') ?>&nbsp;&copy;&nbsp;
                        <a href="https://taymac.net" target="_blank">Taymac</a>
                    </div>
                </div>
                <div class="kt-footer__menu">
                    <a href="javascript:;">Developers</a>
                    <a href="javascript:;">Contact</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end:: Footer --> </div>
</div>
</div>

<!-- end:: Page -->

<!-- begin::Scrolltop -->
<div id="kt_scrolltop" class="kt-scrolltop">
    <i class="fa fa-arrow-up"></i>
</div>
<!-- end::Scrolltop -->

<!-- begin::Global Config(global config for global JS sciprts) -->
<script>
    var KTAppOptions = {
        "colors": {
            "state": {
                "brand": "#366cf3",
                "light": "#ffffff",
                "dark": "#282a3c",
                "primary": "#5867dd",
                "success": "#34bfa3",
                "info": "#36a3f7",
                "warning": "#ffb822",
                "danger": "#fd3995"
            },
            "base": {
                "label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
                "shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
            }
        }
    };
</script>
<!-- end::Global Config -->

<!--begin::Global Theme Bundle(used by all pages) -->
<script src="newassets/plugins/global/plugins.bundle.js" type="text/javascript"></script>
<script src="newassets/js/scripts.bundle.js" type="text/javascript"></script>
<!--end::Global Theme Bundle -->

<!--begin::Page Vendors(used by this page) -->
<script src="newassets/plugins/custom/fullcalendar/fullcalendar.bundle.js" type="text/javascript"></script>
<script src="newassets/plugins/custom/gmaps/gmaps.js" type="text/javascript"></script>
<!--end::Page Vendors -->

<!--begin::Page Scripts(used by this page) -->
<script src="newassets/js/pages/dashboard.js" type="text/javascript"></script>

<script src="newassets/js/pages/custom/login/login-general.js" type="text/javascript"></script>
<script src="newassets/js/pages/crud/forms/widgets/select2.js" type="text/javascript"></script>
<script src="newassets/plugins/custom/datatables/datatables.bundle.js" type="text/javascript"></script>
<script src="newassets/js/pages/crud/datatables/extensions/buttons.js" type="text/javascript"></script>
<script src="newassets/js/pages/notify.js" type="text/javascript"></script>
<script src="newassets/js/custom.js" type="text/javascript"></script>
<script src="newassets/js/scriptsnew.js" type="text/javascript"></script>
<script src="newassets/js/pages/crud/forms/widgets/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="newassets/jquery-confirm/js/jquery-confirm.js" type="text/javascript"></script>
<script src="assets/vendor/sweetalert/sweetalert.min.js"></script>
<!--end::Page Scripts -->
</body>
<!-- end::Body -->

</html>